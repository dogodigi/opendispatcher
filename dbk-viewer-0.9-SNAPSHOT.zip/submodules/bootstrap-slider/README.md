bootstrap-slider
================

a slider plugin base on http://www.eyecon.ro/bootstrap-slider, resolve the jQuery UI slider and bootstrap-slider conflict
